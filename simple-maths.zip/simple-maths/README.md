# simple maths

A Pen created on CodePen.io. Original URL: [https://codepen.io/Abhijith-Reddy/pen/VwOxrjN](https://codepen.io/Abhijith-Reddy/pen/VwOxrjN).

