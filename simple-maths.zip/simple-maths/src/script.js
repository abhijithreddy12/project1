const startContainer = document.getElementById('start-container');
const gameContainer = document.getElementById('game-container');
const questionContainer = document.getElementById('question-container');
const answerInput = document.getElementById('answer-input');
const submitButton = document.getElementById('submit-button');
const continueButton = document.getElementById('continue-button');
const retryButton = document.getElementById('retry-button');
const resultContainer = document.getElementById('result-container');
const scoreContainer = document.getElementById('score');
const levelContainer = document.getElementById('level');
const timerContainer = document.getElementById('timer');
const startButton = document.getElementById('start-button');

const LEVEL_SCORE = 10; // Points required to advance to the next level
const GAME_DURATION = 120; // Game duration in seconds (2 minutes)

let score = 0;
let level = 1;
let timer = GAME_DURATION;
let currentQuestion;
let timerInterval;

// Generate a new question based on the level
function generateQuestion() {
    let num1, num2, operation, difficultyFactor;
    const operations = ['+', '-', '*', '/'];

    // Increase difficulty based on the level
    if (level === 1) {
        num1 = Math.floor(Math.random() * 10) + 1;
        num2 = Math.floor(Math.random() * 10) + 1;
    } else if (level === 2) {
        num1 = Math.floor(Math.random() * 50) + 1;
        num2 = Math.floor(Math.random() * 50) + 1;
    } else {
        difficultyFactor = level * 10;
        num1 = Math.floor(Math.random() * difficultyFactor) + 1;
        num2 = Math.floor(Math.random() * difficultyFactor) + 1;
    }

    operation = operations[Math.floor(Math.random() * operations.length)];

    switch (operation) {
        case '+':
            currentQuestion = {
                question: `${num1} + ${num2}`,
                answer: num1 + num2
            };
            break;
        case '-':
            currentQuestion = {
                question: `${num1} - ${num2}`,
                answer: num1 - num2
            };
            break;
        case '*':
            currentQuestion = {
                question: `${num1} * ${num2}`,
                answer: num1 * num2
            };
            break;
        case '/':
            currentQuestion = {
                question: `${num1} / ${num2}`,
                answer: parseFloat((num1 / num2).toFixed(2))
            };
            break;
    }

    questionContainer.textContent = currentQuestion.question;
    answerInput.value = '';
    answerInput.focus();
}

// Check the answer
function checkAnswer() {
    const userAnswer = parseFloat(answerInput.value);
    if (userAnswer === currentQuestion.answer) {
        score++;
        resultContainer.textContent = 'Correct!';
    } else {
        resultContainer.textContent = `Wrong! The correct answer was ${currentQuestion.answer}`;
    }
    scoreContainer.textContent = score;

    // Check if player advances to the next level
    if (score >= LEVEL_SCORE) {
        level++;
        levelContainer.textContent = level;
        clearInterval(timerInterval); // Stop the timer
        showContinuePrompt();
        return; // Exit function to prevent generating new question immediately
    }

    generateQuestion();
}

// Show continue prompt after completing the level
function showContinuePrompt() {
    continueButton.style.display = 'inline-block';
    submitButton.disabled = true;
    answerInput.disabled = true;
}

// Continue to the next level
function continueToNextLevel() {
    continueButton.style.display = 'none';
    submitButton.disabled = false;
    answerInput.disabled = false;
    score = 0; // Reset score for the next level
    scoreContainer.textContent = score;
    generateQuestion();
    startTimer();
}

// Retry the current level
function retryLevel() {
    retryButton.style.display = 'none';
    submitButton.disabled = false;
    answerInput.disabled = false;
    score = 0; // Reset score for the retry
    scoreContainer.textContent = score;
    generateQuestion();
    startTimer();
}

// Start the game timer
function startTimer() {
    timer = GAME_DURATION;
    timerContainer.textContent = timer;
    timerInterval = setInterval(() => {
        timer--;
        timerContainer.textContent = timer;
        if (timer <= 0) {
            clearInterval(timerInterval);
            if (score < LEVEL_SCORE) {
                showRetryPrompt();
            } else {
                endGame();
            }
        }
    }, 1000);
}

// Show retry prompt after failing to complete the level
function showRetryPrompt() {
    retryButton.style.display = 'inline-block';
    submitButton.disabled = true;
    answerInput.disabled = true;
    questionContainer.textContent = 'Time\'s up! Try again?';
}

// End the game
function endGame() {
    questionContainer.textContent = 'Game Over!';
    resultContainer.textContent = '';
    submitButton.disabled = true;
    answerInput.disabled = true;
    continueButton.style.display = 'none'; // Hide continue button
    retryButton.style.display = 'none'; // Hide retry button
}

// Initialize the game
function startGame() {
    score = 0;
    level = 1;
    scoreContainer.textContent = score;
    levelContainer.textContent = level;
    submitButton.disabled = false;
    answerInput.disabled = false;
    generateQuestion();
    startTimer();
}

// Show the game container and start the game
function showGameContainer() {
    startContainer.style.display = 'none';
    gameContainer.style.display = 'flex';
    startGame();
}

// Event listeners
submitButton.addEventListener('click', checkAnswer);
continueButton.addEventListener('click', continueToNextLevel);
retryButton.addEventListener('click', retryLevel);
startButton.addEventListener('click', showGameContainer);
